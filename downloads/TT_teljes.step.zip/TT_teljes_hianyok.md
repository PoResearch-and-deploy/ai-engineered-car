# TT_teljes.step – hiánylista és helyettesítések (R2 rögzítés-javítás, 2026-11-05)

Forrás: **R2 `r2_geometry.json`** (592 elem = az R 532 eleme − 1 törölt + 61 új; az R2-ben 25 elem módosult). A C3 kardán-orientációk és a **fektetett pótkerék** már a bemenetben vannak. Jármű-KR: x előre, y balra, z fel, mm; origó a hátsó tengely közepe a talajon. Statikus póz: első h=0, s=0; hátsó h=0; 1. fokozat.

Recept: változatlan (C2–C4: könyvtári STEP ↔ LDraw-KR regisztráció; prototípus az LDraw-lokális KR-ben, példány-hely = (R, pozíció)). Író: OpenCASCADE XCAF, AP214, mm, nevek + színek.

## Mi változott az R-hez képest (R2: burkolat-tartók + hátsó pinion 2. csapágya)

| | eredeti (SW-átnézés előtt) | R | **R2** |
|---|---|---|---|
| Elem | 485 | 532 | **592** |
| Lebegő elem (kapcsolati gráf) | 42 | 5 | **0** |
| Merevnek szánt, de egy vonalon forgóan lógó csoport | 14 | 5 | **1** (A6c_VH_B1_60483, váltó-választó, nem burkolat) |
| Tengelyirányban nem rögzített | 11 | 10 | **6** (mind vázbeli) |
| Ütközés, burkolat + új elemek (> 3 mm³) | – | 18 | **1** (pótkerék 6L tengely ↔ felni 6 mm³) |

- **Ajtólap (64782) – feljebb, a felhasználó döntése szerint:** +28 mm z (alsó éle 88.8 mm, a sárvédő-tartók fölött), 8 mm hátrébb, 4 mm **befelé** (nem kijjebb). Tartó: 5L távtartó (32316) a bukó-oszlophoz, 3 csapvonal. Felső éle egy szintben a bukó tetejével; hézag a nem kapcsolódó elemekhez ≥ 2.38 mm.
- **Plató-oldalak (62531):** 8 mm hátrébb, 8 mm befelé; a PF1/PF2 bordák 11L → 13L (41239), oldalanként 2 függőleges csap.
- **Motorháztető-szárnyak (18944):** +4 mm x; tartólánc torony-tengely 11L → 2× 6536 → 3×5 L → 13L gerenda → 2 csap. Szárny ↔ sárvédő-toldat 0.42 mm (érintés-közeli).
- **Orr-rács (15458):** oldalanként 5L homlok-keret gerenda, 2 csap; a rács +2 mm x, **+4 mm y** (a rács furatai 8n-en, a jármű y-rácsa 4 + 8n-en → 4 mm aszimmetria).
- **Sárvédő-toldatok (71689, 4 db):** 41677 kar a második, nem egytengelyű kötéshez – nem fordulhatnak el.
- **Hátsó pinion (7. pont):** a 32123a félpersely helyett 2. csapágy (6632, x 24.1–28.1); a két 6632 2× 2L tengellyel merev bak, 2× 6536 + 2 csap a hídház z-furataiba (x 24.1, y ±20). Hézag: hátsó villa 360° 0.88 mm, első villa ±15° 4.53 mm, váz a teljes hátsó mozgásban 2.81 mm.
- Cikkszám-változás az R-hez képest: +18 2780, +6 6558, +6 6536, +9 41677, +2 6632, +8 32062, +4 32316, +4 41239, +2 32526, +2 23948, +4 3705; −2 3707, −2 32525, −1 32123a.

## Nyitott pontok (ebben a STEP-ben így szerepelnek)

- Orr-rács: 4 mm-es oldalirányú aszimmetria (fél-osztásos alkatrész nélkül nincs más megoldás).
- A két hídház-fél (64179) a gráfban csak érintkezéssel kapcsolódik (A2-örökség); a pinion-bak mindkét félhez 1-1 csapvonallal kötődik.
- A6c_H88_32065 alsó vége: tengelyirányban csak felül rögzített. A6c_VH_B1_60483 egy vonalon ül (váltó-választó).
- Pótkerék: 6 mm³ átfedés a 6L tengely és a felni között.

## Összefoglaló

| | db |
|---|---|
| Elem összesen | **592** |
| Könyvtári STEP-ből, 1:1 | 542 |
| ebből tükrözött orientáció → forgatással | 14 |
| Helyettesítve (más cikkszám lib-STEP-je) | 34 |
| Több lib-darabból összerakva (76537, 61903) | 6 |
| LDraw-hálóból (faceted) | 10 |
| Egyedi alkatrész-prototípus a fájlban | 121 |
| Levél-komponens (darab) | 619 |

Befoglaló méret (a STEP-ből visszaolvasva): **347.8 × 196.0 × 142.8 mm** (x -75.9…271.9, y -98.0…98.0, z 0.0…142.8). Az R-hez képest +10.3 mm hossz: a plató-oldalak 8 mm-rel hátrébb, az orr-rács 2 mm-rel előrébb került.

## Hierarchia

`TT_teljes` → `01_Vaz` (01a…01e) · `02_Elso_futomu` · `03_Kormany` · `04_Elso_osztomu` · `05_Kozepso_hajtaslanc` · `06_Hatso_hid` · `07_Valto` · `08_V8` · `09_Burkolat` · **`10_Rogzites`** (új: az R-lépés tartói, csapjai, perselyei). Komponensnév = `cikkszám_elem-név`.

| Részegység | levél-komponens |
|---|---|
| 01_Vaz | 243 |
| 02_Elso_futomu | 46 |
| 03_Kormany | 12 |
| 04_Elso_osztomu | 20 |
| 05_Kozepso_hajtaslanc | 15 |
| 06_Hatso_hid | 77 |
| 07_Valto | 29 |
| 08_V8 | 32 |
| 09_Burkolat | 51 |
| 10_Rogzites | 94 |

## Új cikkszámok a könyvtárban

| Cikkszám | Forrás | Megjegyzés |
|---|---|---|
| 32526 (L-gerenda 3×5) | `cad/lib/E1_gerendak/32526_L-gerenda_3x5.step` (a gépről, csak olvasva) | új regisztráció a feat.mesh LDraw-hálóhoz: medián 0.77 mm, p90 0.61/1.11 mm; 12 db |
| **50451 (16L tengely)** | **nincs lib-STEP → LDraw-hálóból (faceted)** | A6b_X1_keresztengely (11L → 16L); felület-test lesz SW-ben |
| 32316 (5L gerenda) | `cad/lib/E1_gerendak/32316_gerenda_5L` (már regisztrálva) | R2: ajtó-távtartó + homlok-keret, 4 db |
| **41239 (13L gerenda)** | **csak STL a könyvtárban → LDraw-hálóból (faceted)** | R2: PF1/PF2 plató-bordák + motorháztető-gerendák, 4 db |

## LDraw-hálóból (faceted) – nincs könyvtári STEP

| Elem | Cikkszám | Megjegyzés |
|---|---|---|
| lecvezeto_elso_2905 | 2905 | nincs lib-STEP (háromszög-lap 5×3) – LDraw-hálóból |
| a2_rugostag_bal_b_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála) |
| a2_rugostag_bal_k_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála) |
| a2_rugostag_jobb_b_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála) |
| a2_rugostag_jobb_k_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála) |
| A6b_X1_keresztengely_11L_23948 | 50451 | nincs lib-STEP (16L tengely, R rögzítés) – LDraw-hálóból |
| A6b_PL_PF1_borda_32525, A6b_PL_PF2_borda_32525 | 41239 | nincs lib-STEP (13L gerenda, R2 plató-borda) – LDraw-hálóból |
| R2_mh_gerenda_41239_B / _J | 41239 | nincs lib-STEP (13L gerenda, R2 motorháztető-tartó) – LDraw-hálóból |

## Helyettesítések (C4-döntések)

| Cikkszám | Helyette | db |
|---|---|---|
| 32017 | 11478 (azonos befoglaló, tengelyfuratos) | 1 |
| 32291 | 2× 6536 egymás mellett (x ±4) | 15 |
| 3704 | 32062 (2L tengely, rovátkás) | 8 |
| 87083 | 3705_v2 (a stop-perem nélkül) | 10 |

## Összerakott elemek

- **76537 első rugóstag (4 db):** henger (`76537_rugostag-henger`) a felső szemnél (pozíció + R·[0, L, 0], L = `rugostag_hossz_mm` ≈ 40.2), dugattyúrúd (`76537_rugostag-dugattyurud`) az alsó szemnél, rugó (`76537_rugostag-rugo_v2`) a rúd KR-ében – **a rugó szabad hosszon van** (44 mm-es szemtávra), ezért ≈ 3.8 mm-rel belelóg a hengerbe (STEP-ben nem lehet nem-merev összenyomást adni).
- **61903 kormánykardán (K_UJ1, K_UJ2):** 2× villa (`61903_kardan-villa-A`) + kereszt (`61903_kardan-kereszt`), a második villa a másik kardán felé fordítva (C2-recept). A C2-ben használt +0.8 mm-es kormány-z-eltolást (V9) **nem** vettem át – minden az a6d szerint áll.


## Orientáció-javítások

- kerekhordozo_65766_J (23801): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- agy_92909_J (92909): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- cv_32494_J (32494): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.12 mm)
- gombcsap_felso_6628_J (6628): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- gombcsap_also_6628_J (6628): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- gombtengely_kulso_2736_J (2736): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- felni_15038_J (15038): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- gumi_44771_J (44771): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_31794_J (31794): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_gerenda_32523_h_J (32523): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_gerenda_32523_e_J (32523): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- felso_kar_57515_J (57515): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- nyomtavrud_32005_J (32005): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 1.20 mm)
- gombtengely_belso_2736_J (2736): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- a2 hátsó rugók (u9409-f1): az R-geometria mátrixa szándékosan nem-merev – a háló a jármű-KR-be transzformálva, azonosság-hellyel került be.
- A C3 kardán-orientációk és a pótkerék-póz már az `r2_geometry.json`-ban vannak (nem a build írja felül).


## Regisztráció – ahol a könyvtári alkatrész kevésbé LDraw-hű (medián oda-vissza távolság > 1 mm)

| Kulcs | könyvtári fájl | medián [mm] | forrás |
|---|---|---|---|
| 15038 | 15038_felni_56x34 | 3.35 | C2-C4 reg |
| 44771 | 44771_gumi_68x36 | 2.54 | C2-C4 reg |
| 64782 | 64782_burkololap_5x11 | 1.92 | uj reg |
| 76537h | 76537_rugostag-henger | 1.89 | C2 reg (4254) |
| 32072 | 32072_reces-kerek | 1.61 | C2-C4 reg |
| 15458 | 15458_panel-lap_3x11 | 1.48 | uj reg |
| 76537r | 76537_rugostag-dugattyurud | 1.46 | C2 reg (4255) |
| 76537s | 76537_rugostag-dugattyurud | 1.46 | C2 reg (4255) |
| 62531 | 62531_sima_panel_11x2x3_v1 | 1.42 | uj reg |
| 64179 | 64179_keret-5x7-hidhaz | 1.34 | C2-C4 reg |
| 62821 | 62821_differencialmu_z28_v2 | 1.20 | C2-C4 reg |
| 69911 | 69911_ives_sarvedo_13x2x5_v1 | 1.18 | uj reg |
| 23801 | 65766_kerekhordozo_v2 | 1.14 | C2-C4 reg |
| 32278 | 32278_gerenda_15L | 1.01 | C2-C4 reg |

A 15038 / 44771 (kerék) és a 62821 / 64179 nagy értéke a részletekből (küllők, profil, fogazás) adódik, a pozíció jó; a **64782 burkolólap** (E10, nem LDraw-hű) illeszkedése a leggyengébb (p90 4.8 mm) – érdemes ránézni.


## Ismert ütközések / nyitott pontok (C2–C4 naplókból + R; a STEP a bemenetet követi)

- bolygó (6589) ↔ diff-ház (62821) ≈ 38.5 mm³ – mindhárom differenciálműben (lib-hiba)
- napkerék-csoport ↔ 62821 (hátsó ≈ 98.8 mm³/oldal)
- K80/K120 4 db 32123a persely y = ±26-on a hossztartóba lóg (58.5/55.6 mm³) – C4 szerint y = ±34 a helyes (A6d/A3 javítandó)
- hátsó rugóstag-henger (2909_v2 fül) ↔ hídház ≈ 16.3 mm³/oldal
- 92909 ↔ 65766 59 mm³ (a6d 11.8 mm-es ülés vs. K8 12.0 mm)
- kardánvillák ↔ kereszt / 4519 (szűk lib-tengelyfurat) 5–36 mm³
- a 31794 kart és a 6630 léc háló-alapú; a rugók (u9409, 76537 rugó) csak közelítők

- R2: az ajtólap ↔ sárvédő-tartó ütközés (R: 16 pár) megszűnt (ajtó feljebb); megmaradt: pótkerék 6L tengely ↔ felni 6 mm³


## Ellenőrzés (a kész STEP visszaolvasva, OCC XCAF)

- Elem-szintű komponensek: **592 / 592**; levél-komponens 619.
- Véletlen minta (benne 6 új/javított elem) – a komponens globális helye vs. `r2_geometry.json` `pozicio`:

| Elem | Cikkszám | Részegység | Δp [mm] | módszer |
|---|---|---|---|---|
| A6b_PL_PF1_csap_2780_J | 2780 | 01_Vaz/01d_Hatso_konzolok_tornyok_padlo | 0.00000 | lib |
| a2_gumi_bal_44771 | 44771 | 06_Hatso_hid | 0.00000 | lib |
| P_sarvedo_toldat_E_71689_J | 71689 | 09_Burkolat | 0.00000 | lib |
| ikerful_1_41677_B | 41677 | 01_Vaz/01b_Elso_reszletek | 0.00000 | lib |
| lecvezeto_tengely_jobb_2L_3704 | 3704 | 01_Vaz/01b_Elso_reszletek | 0.00000 | subst |
| a3_UJ_b_elso_villa_62520 | 62520 | 05_Kozepso_hajtaslanc | 0.00000 | lib |
| A6c_V8_FP56_32063 | 32063 | 01_Vaz/01e_Valtohaz_motortarto | 0.00000 | lib |
| vazoszlop_belso_11478_J | 11478 | 01_Vaz/01b_Elso_reszletek | 0.00000 | lib |
| R2_mh_csap_L_x220_2780_J | 2780 | 10_Rogzites | 0.00000 | lib |
| R_Ee_csap_z1_2780_B | 2780 | 10_Rogzites | 0.00000 | lib |
| P_sarvedo_toldat_E_71689_B | 71689 | 09_Burkolat | 0.00000 | lib |
| C_tengely_toldat_Eh_2L_32062_J | 4519 | 09_Burkolat | 0.00000 | lib |
| R2_toldat_tengely2_Ee_B | 32062 | 10_Rogzites | 0.00000 | lib |
| R2_mh_csap_szarny_x148_2780_B | 2780 | 10_Rogzites | 0.00000 | lib |
| rugostag_76537_0_1 | 76537 | 02_Elso_futomu | 0.00000 | multi |
| kerekhordozo_65766_J | 23801 | 02_Elso_futomu | 0.00000 | lib(tukor->forgatas) |

Legnagyobb eltérés 0.00000 mm (követelmény: < 0.1 mm).


## Fájlok

- `TT_teljes.step` (AP214, ≈ 131 MB) · `TT_teljes_elonezet_1_izometrikus.png`, `_2_oldal.png`, `_3_hatso_felulnezet.png`
- Szkriptek (felhő): `/home/claude/work/export/py/` – `build_step.py` és `verify.py` most `TT_GEOM` bemenettel (R), `libmap.py` (+32526, +50451 és +41239 faceted); a mozgó glb-hez `site/tools/r_remap.py` (TT_GEOM + r2/after2.pkl), `cache/reg_final_R.json`.

**SolidWorks-importnál:** ≈ 2 M STEP-entitás; „Import as assembly”, a faceted testek külön figyelmeztetést adhatnak.
