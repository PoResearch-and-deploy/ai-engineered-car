# TT_teljes.step – hiánylista és helyettesítések (2026-11-05)

Forrás: A6d (443 elem, `a6d_geometry.json`, statikus póz, 1. fokozat) + A7 V2 burkolat (42 elem; a pótkerék **állítva** a plató végén, mint a previs_v3-ban). Jármű-KR: x előre, y balra, z fel, mm; origó a hátsó tengely közepe a talajon.

Recept: C2–C4 (könyvtári STEP ↔ LDraw-KR regisztráció, 24 tengelyforgatás + eltolás). A prototípus a könyvtári STEP az LDraw-lokális KR-ben, a példány helye = az a6d (R, pozíció) – így a STEP-ben a komponens-transzformáció közvetlenül összevethető az a6d-vel. Író: OpenCASCADE 7.9 XCAF, AP214, mm, nevek + színek; minden valós szám tizedesponttal.

## Összefoglaló

| | db |
|---|---|
| Elem összesen (a6d + burkolat) | **485** (= 443 + 42) |
| Könyvtári STEP-ből, 1:1 | 444 |
| ebből tükrözött orientáció → forgatással | 14 |
| Helyettesítve (más cikkszám lib-STEP-je) | 30 |
| Több lib-darabból összerakva (76537, 61903) | 6 |
| LDraw-hálóból (faceted) | 5 |
| Egyedi alkatrész-prototípus a fájlban | 105 |
| Levél-komponens (darab) | 508 |

Befoglaló méret (a STEP-ből visszaolvasva): **340.0 × 196.0 × 176.0 mm** (x -70.4…269.6, y -98.0…98.0, z 0.0…176.0).

## Hierarchia

`TT_teljes` → `01_Vaz` (01a létrakeret, 01b első részletek, 01c bukócső/HoG-tartó, 01d hátsó konzolok/tornyok/padló, 01e váltóház+motortartó) · `02_Elso_futomu` · `03_Kormany` · `04_Elso_osztomu` · `05_Kozepso_hajtaslanc` · `06_Hatso_hid` · `07_Valto` · `08_V8` · `09_Burkolat`. Komponensnév = `cikkszám_a6d-név`, alkatrész (prototípus) neve = `cikkszám_könyvtári-név`.

| Részegység | levél-komponens |
|---|---|
| 01_Vaz | 245 |
| 02_Elso_futomu | 46 |
| 03_Kormany | 12 |
| 04_Elso_osztomu | 20 |
| 05_Kozepso_hajtaslanc | 15 |
| 06_Hatso_hid | 67 |
| 07_Valto | 29 |
| 08_V8 | 32 |
| 09_Burkolat | 42 |

## LDraw-hálóból (faceted) – nincs könyvtári STEP

| Elem | Cikkszám | Megjegyzés |
|---|---|---|
| lecvezeto_elso_2905 | 2905 | nincs lib-STEP (háromszög-lap 5×3) – LDraw-hálóból; felületi test (a LDraw-háló nem zárt → SW-ben felület-test lesz) |
| a2_rugostag_bal_b_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála); felületi test (a LDraw-háló nem zárt → SW-ben felület-test lesz) |
| a2_rugostag_bal_k_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála); felületi test (a LDraw-háló nem zárt → SW-ben felület-test lesz) |
| a2_rugostag_jobb_b_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála); felületi test (a LDraw-háló nem zárt → SW-ben felület-test lesz) |
| a2_rugostag_jobb_k_rugo | u9409-f1 | rugó (puha 9L) – nincs lib-STEP, LDraw-hálóból (összenyomott hossz, nem-merev skála); felületi test (a LDraw-háló nem zárt → SW-ben felület-test lesz) |

A 31794 (alsó lengőkar) és a 6630 (fogasléc) könyvtári STEP-je maga is LDraw-hálóból készült (K9_cad1 `_ldrawhalo_v1`) – ezek is háromszögelt testek, nagyok (≈ 26 000 lap).

## Helyettesítések (C4-döntések)

| Cikkszám | Helyette | db |
|---|---|---|
| 32017 | 11478 (azonos befoglaló, tengelyfuratos) | 1 |
| 87083 | 3705_v2 (a stop-perem nélkül) | 10 |
| 3704 | 32062 (2L tengely, rovátkás) | 8 |
| 32291 | 2× 6536 egymás mellett (x ±4) | 11 |

## Összerakott elemek

- **76537 első rugóstag (4 db):** henger (`76537_rugostag-henger`) a felső szemnél (pozíció + R·[0, L, 0], L = `rugostag_hossz_mm` ≈ 40.2), dugattyúrúd (`76537_rugostag-dugattyurud`) az alsó szemnél, rugó (`76537_rugostag-rugo_v2`) a rúd KR-ében – **a rugó szabad hosszon van** (44 mm-es szemtávra), ezért ≈ 3.8 mm-rel belelóg a hengerbe (STEP-ben nem lehet nem-merev összenyomást adni).
- **61903 kormánykardán (K_UJ1, K_UJ2):** 2× villa (`61903_kardan-villa-A`) + kereszt (`61903_kardan-kereszt`), a második villa a másik kardán felé fordítva (C2-recept). A C2-ben használt +0.8 mm-es kormány-z-eltolást (V9) **nem** vettem át – minden az a6d szerint áll.

## Orientáció-javítások

- kerekhordozo_65766_J (23801): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- agy_92909_J (92909): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- cv_32494_J (32494): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.12 mm)
- gombcsap_felso_6628_J (6628): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- gombcsap_also_6628_J (6628): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- gombtengely_kulso_2736_J (2736): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- felni_15038_J (15038): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- gumi_44771_J (44771): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_31794_J (31794): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_gerenda_32523_h_J (32523): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- also_kar_gerenda_32523_e_J (32523): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- felso_kar_57515_J (57515): tükrözött orientáció (det<0) → R·M (szimmetriasík [-1, 1, 1], illesztés p95 0.00 mm)
- nyomtavrud_32005_J (32005): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 1.20 mm)
- gombtengely_belso_2736_J (2736): tükrözött orientáció (det<0) → R·M (szimmetriasík [1, -1, 1], illesztés p95 0.00 mm)
- a2_kardan_H_hatso_villa: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2_kardan_H_elso_villa: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2_kardan_H_kereszt: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2_koztes_tengely_4519: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2_kardan_F_hatso_villa: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2_kardan_F_kereszt: orientáció a C3 kardan.json-ból (a2_model.mobile_elems, UJ_F = (72,−4,36.8)); eltérés az a6d-től: Δp 0.00 mm
- a2 hátsó rugók (u9409-f1): az a6d mátrixa szándékosan nem-merev (összenyomott rugó skálája) – a háló a jármű-KR-be transzformálva, azonosság-hellyel került be.
- a2 linkek (32293, 32005) és rugóstagok (2909/2910): az a6d és az `a2_geometry.json` egyezik (Δ ≤ 0.2 mm / 0.003), az R ortonormalizálva (SVD).

## Regisztráció – ahol a könyvtári alkatrész kevésbé LDraw-hű (medián oda-vissza távolság > 1 mm)

| Kulcs | könyvtári fájl | medián [mm] | forrás |
|---|---|---|---|
| 15038 | 15038_felni_56x34 | 3.35 | C2-C4 reg |
| 44771 | 44771_gumi_68x36 | 2.54 | C2-C4 reg |
| 64782 | 64782_burkololap_5x11 | 1.92 | uj reg |
| 76537h | 76537_rugostag-henger | 1.89 | C2 reg (4254) |
| 32072 | 32072_reces-kerek | 1.61 | C2-C4 reg |
| 15458 | 15458_panel-lap_3x11 | 1.48 | uj reg |
| 76537r | 76537_rugostag-dugattyurud | 1.46 | C2 reg (4255) |
| 76537s | 76537_rugostag-dugattyurud | 1.46 | C2 reg (4255) |
| 62531 | 62531_sima_panel_11x2x3_v1 | 1.42 | uj reg |
| 64179 | 64179_keret-5x7-hidhaz | 1.34 | C2-C4 reg |
| 62821 | 62821_differencialmu_z28_v2 | 1.20 | C2-C4 reg |
| 69911 | 69911_ives_sarvedo_13x2x5_v1 | 1.18 | uj reg |
| 23801 | 65766_kerekhordozo_v2 | 1.14 | C2-C4 reg |
| 32278 | 32278_gerenda_15L | 1.01 | C2-C4 reg |

A 15038 / 44771 (kerék) és a 62821 / 64179 nagy értéke a részletekből (küllők, profil, fogazás) adódik, a pozíció jó; a **64782 burkolólap** (E10, nem LDraw-hű) illeszkedése a leggyengébb (p90 4.8 mm) – érdemes ránézni.

## Ismert ütközések / nyitott pontok (C2–C4 naplókból, a STEP az a6d-t követi, nem javítottam)

- bolygó (6589) ↔ diff-ház (62821) ≈ 38.5 mm³ – mindhárom differenciálműben (lib-hiba)
- napkerék-csoport ↔ 62821 (hátsó ≈ 98.8 mm³/oldal)
- K80/K120 4 db 32123a persely y = ±26-on a hossztartóba lóg (58.5/55.6 mm³) – C4 szerint y = ±34 a helyes (A6d/A3 javítandó)
- hátsó rugóstag-henger (2909_v2 fül) ↔ hídház ≈ 16.3 mm³/oldal
- 92909 ↔ 65766 59 mm³ (a6d 11.8 mm-es ülés vs. K8 12.0 mm)
- kardánvillák ↔ kereszt / 4519 (szűk lib-tengelyfurat) 5–36 mm³
- a 31794 kart és a 6630 léc háló-alapú; a rugók (u9409, 76537 rugó) csak közelítők

## Ellenőrzés (a kész STEP visszaolvasva, OCC XCAF)

- Elem-szintű komponensek: **485 / 485** (minden a6d-elem és burkolat-elem megvan, egyedi névvel).
- Véletlen minta – a komponens globális helye vs. a6d `pozicio`:

| Elem | Cikkszám | Részegység | Δp [mm] | módszer |
|---|---|---|---|---|
| a2_tavtarto_csapagy_jobb_6632 | 6632 | 06_Hatso_hid | 0.00000 | lib |
| lecvezeto_papucs_jobb_3713 | 3713 | 01_Vaz/01b_Elso_reszletek | 0.00000 | lib |
| a2_kardan_H_elso_villa | 62520 | 06_Hatso_hid | 0.00002 | lib |
| A6b_PL_PF1_csap_2780_B | 2780 | 01_Vaz/01d_Hatso_konzolok_tornyok_padlo | 0.00000 | lib |
| a1c_kimeno_tengely_bal_4519 | 4519 | 04_Elso_osztomu | 0.00000 | lib |
| also_kar_kulso_persely_32123a_1 | 32123a | 02_Elso_futomu | 0.00000 | lib |
| A6b_FK_gombtarto_60483_J | 60483 | 01_Vaz/01d_Hatso_konzolok_tornyok_padlo | 0.00000 | lib |
| also_csuklotengely_6L_3706_B | 3706 | 01_Vaz/01b_Elso_reszletek | 0.00000 | lib |
| rugostag_76537_0_1 | 76537 | 02_Elso_futomu | 0.00000 | multi |
| kerekhordozo_65766_J | 23801 | 02_Elso_futomu | 0.00000 | lib(tukor->forgatas) |

Minden eltérés < 0.001 mm (követelmény: < 0.1 mm).

## Fájlok

- `TT_teljes.step` (AP214, ≈ 115 MB, OCC-író) · `TT_teljes_elonezet_1_izometrikus.png`, `_2_oldal.png`, `_3_hatso_felulnezet.png` (a STEP-ből tesszelálva, Blender Workbench)
- Szkriptek (felhő): `/home/claude/work/export/py/` – `libmap.py` (cikkszám → lib-STEP), `tess_all.py`, `reg_all.py` + `reg_cmp.py` (regisztráció; a C2–C4 Q/t-t használja, ha legalább olyan jó), `build_step.py`, `verify.py`, `render_prev.py`.

**SolidWorks-importnál:** nagy fájl (≈ 2 M STEP-entitás); a 31794/6630 háló-testek lassíthatnak. Ha az import lassú: Import Options → „Import as assembly”, a felület-testek (faceted) külön figyelmeztetést adhatnak.
